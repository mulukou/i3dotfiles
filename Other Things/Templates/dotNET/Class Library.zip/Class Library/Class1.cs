﻿using System;

namespace dotNET
{
    public class Class1
    {
    }
}
